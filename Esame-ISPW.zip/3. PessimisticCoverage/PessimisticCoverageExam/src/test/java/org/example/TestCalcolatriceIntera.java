package org.example;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class TestCalcolatriceIntera {

    @Test
    void testSomma1() {
        CalcolatriceIntera calcolatriceIntera = new CalcolatriceIntera();
        int n1 = 11;
        int n2 = 3;
        int expectedValue = n1+n2;
        int actualValue = calcolatriceIntera.somma(n1, n2);
        assertEquals(expectedValue, actualValue);
    }

    @Test
    void testDifferenza1() {
        CalcolatriceIntera calcolatriceIntera = new CalcolatriceIntera();
        int n1 = 11;
        int n2 = 3;
        int expectedValue = n1-n2;
        int actualValue = calcolatriceIntera.differenza(n1, n2);
        assertEquals(expectedValue, actualValue);
    }

    @Test
    void testMoltiplicazione1() {
        CalcolatriceIntera calcolatriceIntera = new CalcolatriceIntera();
        int n1 = 11;
        int n2 = 3;
        int expectedValue = n1*n2;
        int actualValue = calcolatriceIntera.moltiplicazione(n1, n2);
        assertEquals(expectedValue, actualValue);
    }

    @Test
    void testDivisione1() {
        CalcolatriceIntera calcolatriceIntera = new CalcolatriceIntera();
        int n1 = 11;
        int n2 = 3;
        int expectedValue = n1/n2;
        int actualValue = calcolatriceIntera.divisione(n1, n2);
        assertEquals(expectedValue, actualValue);
    }

    @Test
    void testSomma2() {
        CalcolatriceIntera calcolatriceIntera = new CalcolatriceIntera();
        int n1 = 11;
        int n2 = 3;
        int n = 10;
        int expectedValue = n+(n1+n2);
        calcolatriceIntera.somma(n1, n2);
        int actualValue = calcolatriceIntera.somma(n);
        assertEquals(expectedValue, actualValue);
    }

    @Test
    void testDifferenza2() {
        CalcolatriceIntera calcolatriceIntera = new CalcolatriceIntera();
        int n1 = 11;
        int n2 = 3;
        int n = 10;
        int expectedValue = n-(n1-n2);
        calcolatriceIntera.differenza(n1, n2);
        int actualValue = calcolatriceIntera.differenza(n);
        assertEquals(expectedValue, actualValue);
    }

    @Test
    void testMoltiplicazione2() {
        CalcolatriceIntera calcolatriceIntera = new CalcolatriceIntera();
        int n1 = 11;
        int n2 = 3;
        int n = 10;
        int expectedValue = n*(n1*n2);
        calcolatriceIntera.moltiplicazione(n1, n2);
        int actualValue = calcolatriceIntera.moltiplicazione(n);
        assertEquals(expectedValue, actualValue);
    }

    @Test
    void testDivisione2() {
        CalcolatriceIntera calcolatriceIntera = new CalcolatriceIntera();
        int n1 = 11;
        int n2 = 3;
        int n = 10;
        int expectedValue = n/(n1/n2);
        calcolatriceIntera.divisione(n1, n2);
        int actualValue = calcolatriceIntera.divisione(n);
        assertEquals(expectedValue, actualValue);
    }
}