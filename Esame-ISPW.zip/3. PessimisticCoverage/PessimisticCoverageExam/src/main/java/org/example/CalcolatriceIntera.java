package org.example;

public class CalcolatriceIntera {

    private int ultimoRisultato;

    public CalcolatriceIntera() {
        this.ultimoRisultato = 0;
    }

    public int somma(int n1, int n2){
        int risultato = n1+n2;
        ultimoRisultato = risultato;
        return risultato;
    }

    public int differenza(int n1, int n2){
        int risultato = n1-n2;
        ultimoRisultato = risultato;
        return risultato;
    }

    public int moltiplicazione(int n1, int n2){
        int risultato = n1*n2;
        ultimoRisultato = risultato;
        return risultato;
    }

    public int divisione(int n1, int n2){
        int risultato = (int) Math.round((double)n1/n2);
        ultimoRisultato = risultato;
        return risultato;
    }


    //le seguenti operazioni sono richiamate per eseguire la relativa operazione con l'ultimo risultato
    public int somma(int n){
        int risultato = n+ultimoRisultato;
        ultimoRisultato =n+ultimoRisultato;
        return risultato;
    }

    public int differenza(int n){
        int risultato = n-ultimoRisultato;
        ultimoRisultato = risultato;
        return risultato;
    }

    public int moltiplicazione(int n){
        int risultato = n*ultimoRisultato;
        ultimoRisultato = risultato;
        return risultato;
    }

    public int divisione(int n){
        int risultato = (int) Math.round((double)n/ultimoRisultato);
        ultimoRisultato = risultato;
        return risultato;
    }
}
