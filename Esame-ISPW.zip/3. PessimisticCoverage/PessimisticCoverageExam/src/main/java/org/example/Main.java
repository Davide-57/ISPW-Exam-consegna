package org.example;

public class Main {
    public static void main(String[] args) {

        CalcolatriceIntera calcolatriceIntera = new CalcolatriceIntera();
        System.out.println(calcolatriceIntera.divisione(8,3));
        System.out.println(calcolatriceIntera.divisione(2));
    }
}